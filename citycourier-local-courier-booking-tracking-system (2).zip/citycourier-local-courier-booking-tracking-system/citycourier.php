<?php
/**
 * Plugin Name: CityCourier – Local Courier Booking & Tracking System
 * Description: A simple and user-friendly courier booking form for WordPress. Includes WooCommerce order integration, Google Maps support, order tracking, and admin management tools.
 * Version: 1.1
 * Author: GKSoft Dev Team
 * Author URI: https://gksoft.dev
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: citycourier-local-courier-booking-tracking-system
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Define constants
if ( ! defined( 'CITYCOURIER_PATH' ) ) {
    define( 'CITYCOURIER_PATH', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'CITYCOURIER_URL' ) ) {
    define( 'CITYCOURIER_URL', plugin_dir_url( __FILE__ ) );
}

define( 'CITYCOURIER_VERSION', '1.1' );

// Load required files
require_once CITYCOURIER_PATH . 'admin/settings-page.php';
require_once CITYCOURIER_PATH . 'includes/class-distance.php';
require_once CITYCOURIER_PATH . 'templates/form-submit-handler.php';

// Start session if needed
add_action( 'init', function() {
    if ( ! session_id() ) {
        session_start();
    }
});

// WooCommerce dependency notice
add_action( 'admin_notices', function() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        printf(
            '<div class="notice notice-error"><p><strong>%1$s:</strong> %2$s</p></div>',
            esc_html__( 'CityCourier', 'citycourier-local-courier-booking-tracking-system' ),
            esc_html__( 'This plugin requires WooCommerce to be installed and active.', 'citycourier-local-courier-booking-tracking-system' )
        );
    }
});

// Add admin menu
add_action( 'admin_menu', function() {
    add_menu_page(
        esc_html__( 'CityCourier Settings', 'citycourier-local-courier-booking-tracking-system' ),
        esc_html__( 'CityCourier', 'citycourier-local-courier-booking-tracking-system' ),
        'manage_options',
        'citycourier-settings',
        'citycourier_settings_page_html',
        'dashicons-location',
        56
    );
    add_submenu_page(
        'citycourier-settings',
        esc_html__( 'Orders', 'citycourier-local-courier-booking-tracking-system' ),
        esc_html__( 'Orders', 'citycourier-local-courier-booking-tracking-system' ),
        'manage_options',
        'citycourier-orders',
        'citycourier_orders_page_html'
    );
    add_submenu_page(
        'citycourier-settings',
        esc_html__( 'Contact', 'citycourier-local-courier-booking-tracking-system' ),
        esc_html__( 'Contact', 'citycourier-local-courier-booking-tracking-system' ),
        'manage_options',
        'citycourier-contact',
        'citycourier_contact_page_html'
    );
});

add_action( 'admin_notices', function() {
    $current = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : ''; // Only used for admin menu display, no data is processed, nonce not required.
    if ( false === strpos( $current, 'citycourier' ) ) {
        return;
    }
    $menu_items = [
        'citycourier-settings' => [ esc_html__( 'Settings', 'citycourier-local-courier-booking-tracking-system' ), '⚙️' ],
        'citycourier-orders'   => [ esc_html__( 'Orders', 'citycourier-local-courier-booking-tracking-system' ), '📦' ],
    ];
    echo '<div class="cc-header-bar">';
    echo '<div class="cc-header-brand">';
    printf(
        '<img src="%1$s" alt="%2$s" />',
        esc_url( 'https://test.gksoft.com.tr/wp-content/uploads/2025/06/cty.png' ),
        esc_attr__( 'City Courier Logo', 'citycourier-local-courier-booking-tracking-system' )
    );
    printf(
        '<div><strong>%1$s</strong><br><span class="version">%2$s: %3$s</span></div>',
        esc_html__( 'City Courier WP Plugin', 'citycourier-local-courier-booking-tracking-system' ),
        esc_html__( 'Version', 'citycourier-local-courier-booking-tracking-system' ),
        esc_html( '1.1' )
    );
    echo '</div>';
    echo '<nav class="cc-header-nav">';
    foreach ( $menu_items as $slug => $data ) {
        list( $label, $icon ) = $data;
        $url   = esc_url( admin_url( 'admin.php?page=' . $slug ) );
        $class = ( $current === $slug ) ? 'active' : '';
        printf(
            '<a href="%1$s" class="%2$s">%3$s %4$s</a>',
            esc_attr($url),
            esc_attr( $class ),
            esc_html( $icon ),
            esc_html( $label )
        );
    }
    echo '</nav>';
    echo '<div class="cc-header-actions"><div class="cc-dropdown"><button class="cc-dropdown-toggle" aria-expanded="false">⋯</button><div class="cc-dropdown-menu">';
    printf(
        '<a href="%1$s" target="_blank">❓ %2$s</a>',
        esc_url( 'https://gksoft.dev/contact' ),
        esc_html__( 'Support', 'citycourier-local-courier-booking-tracking-system' )
    );
    printf(
        '<a href="%1$s">💬 %2$s</a>',
        esc_url( 'mailto:plugins@gksoft.dev?subject=' . rawurlencode( 'CityCourier Feedback' ) ),
        esc_html__( 'Feedback', 'citycourier-local-courier-booking-tracking-system' )
    );
    echo '</div></div></div>';
    echo '</div>';
});

// Shortcode
add_shortcode( 'citycourier_form', function() {
    ob_start();
    require CITYCOURIER_PATH . 'templates/form-wrapper.php';
    return ob_get_clean();
});

// Frontend tracking template
add_action( 'template_redirect', function() {
    if (
        is_page() &&
        isset( $_GET['order_id'] ) && // Only used for displaying the page, no data is updated/deleted, nonce is not required.
        isset( $_SERVER['REQUEST_URI'] ) &&
        false !== strpos( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ), 'courier-tracking' )
    ) {
        include CITYCOURIER_PATH . 'templates/tracking-lite.php';
        exit;
    }
});




add_action( 'admin_enqueue_scripts', function( $hook ) {
    // Sadece citycourier ayar sayfasında yüklensin isterseniz:
    if ( false === strpos( $hook, 'citycourier' ) ) {
        return;
    }
    wp_enqueue_style(
        'citycourier-admin-style',
        CITYCOURIER_URL . 'assets/css/style.css',
        [],
        '1.1'
    );
} );

// Enqueue frontend assets
add_action( 'wp_enqueue_scripts', 'citycourier_enqueue_assets' );
function citycourier_enqueue_assets() {
    $api_key = get_option( 'citycourier_google_api_key' );
    if ( $api_key ) {
        wp_enqueue_script(
            'google-maps',
            "https://maps.googleapis.com/maps/api/js?key={$api_key}&libraries=places",
            [],
            null,
            true
        );
    }

    wp_enqueue_script(
        'citycourier-js',
        CITYCOURIER_URL . 'assets/js/citycourier.js',
        [ 'jquery', 'google-maps' ],
        CITYCOURIER_VERSION,
        true
    );

    // Localize ile verileri JS'e aktar
        wp_localize_script( 'citycourier-js', 'CityCourierData', [
        'ajax_url'        => admin_url( 'admin-ajax.php' ),
        'km_price'        => floatval( get_option('citycourier_km_price', 0) ),
        'minimum_price'   => floatval( get_option('citycourier_minimum_price', 0) ),
        'currency'        => esc_js( get_option('citycourier_currency_symbol', '₺') ),
        'currency_code'   => esc_js( get_option('citycourier_currency', 'TRY') ),
        'max_distance_km' => floatval( get_option('citycourier_max_distance', 0) ),
        'country'         => esc_js( get_option('citycourier_country', 'TR') ),
    ] );


    wp_enqueue_style(
        'citycourier-style',
        CITYCOURIER_URL . 'assets/css/style.css',
        [],
        CITYCOURIER_VERSION
    );
}




// Activation hook: create pages
register_activation_hook( __FILE__, 'citycourier_create_pages' );
function citycourier_create_pages() {
    if ( ! function_exists( 'wp_insert_post' ) ) {
        require_once ABSPATH . 'wp-admin/includes/post.php';
    }

    $pages = [
        'courier-tracking' => '[citycourier_tracking]',
        'courier-form'     => '[citycourier_form]'
    ];

    foreach ( $pages as $slug => $shortcode ) {
        $page = get_page_by_path( $slug );
        if ( ! $page ) {
            $post_id = wp_insert_post( [
                'post_title'     => ucwords( str_replace( '-', ' ', $slug ) ),
                'post_name'      => $slug,
                'post_content'   => $shortcode,
                'post_status'    => 'publish',
                'post_type'      => 'page',
                'comment_status' => 'closed',
            ] );
            if ( ! is_wp_error( $post_id ) ) {
                update_option( "citycourier_{$slug}_page_id", $post_id );
            }
        }
    }
}

<?php
/**
 * templates/form-submit-handler.php
 * Form submit handler
 */
if (!defined('ABSPATH')) exit;


add_action('template_redirect', function () {
    if ( ! isset($_SERVER['REQUEST_METHOD']) || $_SERVER['REQUEST_METHOD'] !== 'POST' ) {
        return;
    }

   if (
        isset($_POST['form_type']) &&
        $_POST['form_type'] === 'review' &&
        isset($_POST['courier_rating'], $_POST['order_id'], $_POST['cc_review_nonce']) &&
        wp_verify_nonce( sanitize_text_field( wp_unslash($_POST['cc_review_nonce']) ), 'cc_review_submit' )
    ) {
        $order_id = absint( wp_unslash($_POST['order_id']) );
        $rating   = intval( wp_unslash($_POST['courier_rating']) );
        $review   = isset($_POST['courier_review']) ? sanitize_textarea_field( wp_unslash($_POST['courier_review']) ) : '';

        update_post_meta($order_id, '_cc_review_rating', $rating);
        update_post_meta($order_id, '_cc_review_text',   $review);

        wp_safe_redirect( add_query_arg([
            'reviewed' => '1',
            'order_id' => $order_id
        ], get_permalink()) );
        exit;
    }
    if (
        isset($_POST['form_type']) &&
        $_POST['form_type'] === 'delivery' &&
        isset(
            $_POST['address_from'], $_POST['address_to'], $_POST['pickup_phone'],
            $_POST['delivery_phone'], $_POST['sender_name'], $_POST['user_name'],
            $_POST['user_email'], $_POST['pickup_details'], $_POST['delivery_details'],
            $_POST['weight'], $_POST['package_content'], $_POST['payment'], $_POST['cc_nonce']
        ) &&
        ! empty($_POST['address_from']) &&
        ! empty($_POST['address_to']) &&
        wp_verify_nonce( sanitize_text_field( wp_unslash($_POST['cc_nonce']) ), 'citycourier_form_submit' )
    ) {
        $api_key = get_option('citycourier_google_api_key', '');
        if ( ! $api_key ) {
            wp_send_json_error('Google API Key eksik. Lütfen ayarlardan doldurun.');
        }

        $origin            = sanitize_text_field( wp_unslash($_POST['address_from']) );
        $destination       = sanitize_text_field( wp_unslash($_POST['address_to']) );
        $pickup_phone      = sanitize_text_field( wp_unslash($_POST['pickup_phone']) );
        $delivery_phone    = sanitize_text_field( wp_unslash($_POST['delivery_phone']) );
        $sender_name       = sanitize_text_field( wp_unslash($_POST['sender_name']) );
        $user_name         = sanitize_text_field( wp_unslash($_POST['user_name']) );
        $user_email        = sanitize_email( wp_unslash($_POST['user_email']) );
        $pickup_details    = sanitize_textarea_field( wp_unslash($_POST['pickup_details']) );
        $delivery_details  = sanitize_textarea_field( wp_unslash($_POST['delivery_details']) );
        $weight            = sanitize_text_field( wp_unslash($_POST['weight']) );
        $package_content   = sanitize_text_field( wp_unslash($_POST['package_content']) );
        $payment_method    = sanitize_text_field( wp_unslash($_POST['payment']) );


        require_once CITYCOURIER_PATH . 'includes/class-distance.php';
        $calc = new CityCourier_DistanceCalculator();
        $distance = $calc->calculate_distance($origin, $destination);
        if (is_wp_error($distance)) {
            wp_send_json_error('Google mesafe bilgisi alınamadı: ' . $distance->get_error_message());
        }

        $km_price  = (float)get_option('citycourier_km_price', 0);
        $min_price = (float)get_option('citycourier_minimum_price', 0);
        $total_fee = round($min_price + ($distance['distance_km'] * $km_price));


        if (!function_exists('wc_create_order')) {
            wp_send_json_error('WooCommerce yüklü değil.');
        }

        $order = wc_create_order();
        $product_id = (int)get_option('citycourier_product_id', 0);
        $order->add_product(wc_get_product($product_id), 1, [
            'subtotal' => $total_fee,
            'total'    => $total_fee
        ]);

        // Meta veriler
        $meta = [
            '_cc_address_from'     => $origin,
            '_cc_address_to'       => $destination,
            '_cc_pickup_phone'     => $pickup_phone,
            '_cc_delivery_phone'   => $delivery_phone,
            '_cc_sender_name'      => $sender_name,
            '_cc_user_name'        => $user_name,
            '_cc_user_email'       => $user_email,
            '_cc_pickup_details'   => $pickup_details,
            '_cc_delivery_details' => $delivery_details,
            '_cc_weight'           => $weight,
            '_cc_package_content'  => $package_content,
            '_cc_payment_method'   => $payment_method,
            '_cc_total_price'      => $total_fee,
            '_cc_duration'         => sanitize_text_field($distance['duration']),
        ];
        foreach ($meta as $key => $val) {
            $order->update_meta_data($key, $val);
        }

        $order->calculate_totals();
        $order->save();

        wp_send_json_success([
            'redirect_url' => site_url('/courier-tracking/?order_id=' . $order->get_id())
        ]);
        exit;
    }

});


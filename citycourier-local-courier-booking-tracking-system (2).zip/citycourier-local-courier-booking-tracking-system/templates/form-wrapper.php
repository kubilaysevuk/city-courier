<?php
/**
 * templates/form-wrapper.php
 * Front-end courier form template
 */
if (!defined('ABSPATH')) exit; 

$min_price    = (float) get_option('citycourier_minimum_price');
$plugin_url   = plugins_url('../assets/img/', __FILE__);
$selected_country = get_option('citycourier_country', 'TR');

$dial_codes = [
    'TR' => '90',  'US' => '1',   'GB' => '44',  'DE' => '49',  'FR' => '33',
    'IT' => '39',  'ES' => '34',  'CA' => '1',   'AU' => '61',  'NL' => '31',
    'BE' => '32',  'CH' => '41',  'AT' => '43',  'AE' => '971', 'RU' => '7',
    'IN' => '91',  'CN' => '86',  'JP' => '81',  'BR' => '55',  'ZA' => '27',
    'PL' => '48',  'SE' => '46',  'NO' => '47',  'FI' => '358', 'DK' => '45',
    'GR' => '30',  'RO' => '40',  'PT' => '351', 'MX' => '52',  'AR' => '54',
    'ID' => '62',  'MY' => '60',  'KR' => '82',  'UA' => '380', 'IL' => '972',
    'IR' => '98',  'SA' => '966'
];
$dial_code = isset($dial_codes[$selected_country]) ? $dial_codes[$selected_country] : '90';

$currency_code = get_option('citycourier_currency', 'USD');
$symbols = [
    'USD' => '$',   'EUR' => '€',   'GBP' => '£',   'TRY' => '₺',   'CAD' => 'C$',
    'AUD' => 'A$',  'CHF' => 'CHF', 'JPY' => '¥',   'CNY' => '¥',   'AED' => 'د.إ',
    'INR' => '₹',   'BRL' => 'R$',  'ZAR' => 'R',   'KRW' => '₩',   'MXN' => '$'
];
$currency_symbol = $symbols[$currency_code] ?? '$';

wp_localize_script('citycourier-js', 'CityCourierData', [
    'km_price'        => (float) get_option('citycourier_km_price', 0),
    'minimum_price'   => (float) get_option('citycourier_minimum_price', 0),
    'currency_symbol' => $currency_symbol,
    'currency_code'   => $currency_code,
    'max_distance_km' => floatval(get_option('citycourier_max_distance', 0)),
    'country'         => $selected_country,
]);
?>

<form id="citycourier-form" class="citycourier-form" method="post" action="">
    <?php wp_nonce_field('citycourier_form_submit', 'cc_nonce'); ?>

    <div class="delivery-type-options city-column1">
        <label class="radio-card-head">
            <input type="radio" name="delivery_type" value="now" checked>
            <div class="option-card radio-card-inner">
                <!-- SVG İkon -->
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none">
                    <path fill="#969493" fill-rule="evenodd" d="M11.727 1.668h.183c.965 0 1.727.75 1.758 1.691v.25c0 .032-.031.059-.059.059h-3.554c-.028 0-.055-.027-.055-.059v-.25c0-.941.766-1.691 1.727-1.691m.226 3h-.078C6.996 4.641 3.027 8.582 3 13.461c-.027 4.875 3.918 8.844 8.793 8.871 4.875.027 8.848-3.914 8.875-8.793.05-4.848-3.84-8.82-8.715-8.871m1.379 8.035c.05.84-.57 1.574-1.398 1.629a1.517 1.517 0 0 1-1.602-1.418v-.156l1.5-6.09Zm0 0" clip-rule="evenodd"></path>
                </svg>
                <h3 class="title">Deliver Now</h3>
                <p class="description">
                    We will assign a nearby 2-Wheeler to pick up and deliver as soon as possible.
                </p>
                <p class="price">from <?php echo esc_html($currency_symbol) . esc_html($min_price); ?></p>
            </div>
        </label>
    </div>

    <div class="form-wrapper">
        <div class="step-indicator">
            <div class="circle">1</div>
            <div class="line"></div>
            <div class="circle">2</div>
        </div>
        <div class="form-sections">
            <div class="address-section">
                <h3>Pick up Address</h3>
                <input type="text" id="address_from" name="address_from" placeholder="Street name & Locality Name" required>
                <div id="map_from" class="map-area" style="display: none; width:100%;height:200px;margin-bottom:10px;"></div>
                <div class="phone_container">
                    <span class="phone_prefix">+<?php echo esc_html($dial_code); ?></span>
                    <input class="phone_input" autocomplete="off" placeholder="10 digit phone" type="tel" name="pickup_phone" required maxlength="10">
                </div>
                <textarea name="pickup_details" placeholder="Apartment, floor, building etc."></textarea>
                <input type="text" id="sender_name" name="sender_name" placeholder="Sender Name" required>
                <input type="email" name="user_email" placeholder="E-Mail" required>
            </div>
            <div class="address-section-2">
                <h3>Delivery Address</h3>
                <input type="text" id="address_to" name="address_to" placeholder="Street name & Locality Name" required>
                <div id="map_to" class="map-area" style="display: none; width:100%;height:200px;margin-bottom:10px;"></div>
                <div class="phone_container">
                    <div class="phone_prefix">+<?php echo esc_html($dial_code); ?></div>
                    <input class="phone_input" autocomplete="off" placeholder="10 digit phone" type="tel" name="delivery_phone" required maxlength="10">
                </div>
                <textarea name="delivery_details" placeholder="Apartment, floor, building etc."></textarea>
                <input type="text" id="user_name" name="user_name" placeholder="Recipient Name" required>
            </div>
        </div>
    </div>

    <div class="package-section city-column1">
        <h3>Package Content</h3>
        <div class="weight-options">
            <?php foreach(['1kg'=>'Up to 1 kg','5kg'=>'Up to 5 kg','10kg'=>'Up to 10 kg','15kg'=>'Up to 15 kg'] as $val=>$label): ?>
    		<label class="radio-card">
        		<input type="radio" name="weight" value="<?php echo esc_attr($val); ?>" <?php echo $val=='1kg' ? 'checked' : ''; ?>>
        	<div class="radio-card-inner"><p><?php echo esc_html($label); ?></p></div>
    		</label>
			<?php endforeach; ?>
        </div>
        <input type="text" name="package_content" placeholder="What are you sending? (e.g. Document, Flowers, Cake)" required>
        <div class="quick-tags">
            <span>Document</span><span>Box</span><span>Food</span>
            <span>Flowers</span><span>Cake</span><span>Bag</span>
        </div>
    </div>

    <div class="city-column1">
        <h3>Payment Type</h3>
        <div class="payment-type">
            <label class="radio-card-footer">
                <input type="radio" name="payment" value="cash" checked>
                <div class="radio-card-inner">
                    <img src="<?php echo esc_url($plugin_url . 'banknotes.png'); ?>" alt="Card" style="height: 28px;">
                    <h4>Cash</h4>
                </div>
            </label>
            <label class="radio-card-footer">
                <input type="radio" name="payment" value="card">
                <div class="radio-card-inner">
                    <img src="<?php echo esc_url($plugin_url . 'debit-card.png'); ?>" alt="Card" style="height: 28px;">
                    <h4>Card</h4>
                </div>
            </label>
        </div>
    </div>

    <div class="form-footer-block city-column1">
        <div class="order-total-block">
            <div class="dv-order-total-price__label">Total:&nbsp;from</div>
            <div class="dv-order-total-price__value"><span><?php echo esc_html($currency_symbol) . esc_html($min_price); ?></span></div>
            <div class="order-total-tooltip">
                <span class="tooltip-icon" tabindex="0">?</span>
                <div class="tooltip-content">
                    Price may vary depending on the selected service.
                </div>
            </div>
        </div>
        <div class="distance-warning" style="display:none; color:#cc0000; font-weight:500; margin-top:10px;"></div>

        <input type="hidden" name="form_type" value="delivery">
        <input type="hidden" name="cc_nonce" value="<?php echo esc_attr( wp_create_nonce('citycourier_form_submit') ); ?>">

        <div class="form-submit-block">
            <button type="submit" class="form-submit-btn">Submit Order</button>
        </div>
        <button type="button" class="action-link" onclick="window.scrollTo({top:0,behavior:'smooth'});">Go to top</button>
    </div>
</form>

<div id="cc-response"></div>


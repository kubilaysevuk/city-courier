<?php
/**
 * templates/tracking-lite.php
 * Front-end courier tracking template (includes theme header and footer)
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Prevent direct access
}

get_header();

// Validate order_id parameter
$order_id = isset( $_GET['order_id'] ) ? absint( wp_unslash( $_GET['order_id'] ) ) : 0;
$nonce    = isset( $_GET['cc_nonce'] ) ? sanitize_text_field( wp_unslash( $_GET['cc_nonce'] ) ) : '';

if ( ! $order_id ) {
    echo '<p>' . esc_html__( 'Invalid or missing order ID.', 'citycourier-local-courier-booking-tracking-system' ) . '</p>';
    get_footer();
    return;
}

// Nonce doğrula
if ( ! $nonce || ! wp_verify_nonce( $nonce, 'cc_track_order_' . $order_id ) ) {
    echo '<p>' . esc_html__( 'Invalid or expired tracking link.', 'citycourier-local-courier-booking-tracking-system' ) . '</p>';
    get_footer();
    return;
}

// Check WooCommerce availability
if ( ! function_exists( 'wc_get_order' ) ) {
    echo '<p>' . esc_html__( 'WooCommerce is not active.', 'citycourier-local-courier-booking-tracking-system' ) . '</p>';
    get_footer();
    return;
}

// Retrieve order object
$order = wc_get_order( $order_id );
if ( ! $order ) {
    echo '<p>' . esc_html__( 'Order not found.', 'citycourier-local-courier-booking-tracking-system' ) . '</p>';
    get_footer();
    return;
}


// Fetch meta data and escape
$origin      = esc_html( $order->get_meta( '_cc_address_from' ) );
$destination = esc_html( $order->get_meta( '_cc_address_to' ) );
$duration    = esc_html( $order->get_meta( '_cc_duration' ) );
$total_fee   = floatval( $order->get_meta( '_cc_total_price' ) );
$status      = esc_html( wc_get_order_status_name( $order->get_status() ) );

// Currency symbol mapping
$currency_code   = get_option( 'citycourier_currency', 'USD' );
$symbols         = [
    'USD' => '$', 'EUR' => '€', 'GBP' => '£', 'TRY' => '₺',
    'CAD' => 'C$', 'AUD' => 'A$', 'CHF' => 'CHF', 'JPY' => '¥',
    'CNY' => '¥', 'AED' => 'د.إ', 'INR' => '₹', 'BRL' => 'R$',
    'ZAR' => 'R', 'KRW' => '₩', 'MXN' => '$',
];
$currency_symbol = $symbols[ $currency_code ] ?? '$';

// WhatsApp contact
$whatsapp_number = get_option( 'citycourier_whatsapp_number', '' );
$whatsapp_href   = $whatsapp_number ? 'tel:' . preg_replace( '/[^\d+]/', '', $whatsapp_number ) : '';
?>
<div class="citycourier-tracking" style="max-width:700px; margin:100px auto;">
    <?php
    /* translators: %d: Order ID */
    echo '<h2>' . esc_html( sprintf( __( '🚚 Order #%d Tracking', 'citycourier-local-courier-booking-tracking-system' ), $order_id ) ) . '</h2>';
    ?>
    <ul>
        <li><strong><?php esc_html_e( 'Status:', 'citycourier-local-courier-booking-tracking-system' ); ?></strong> <?php echo esc_html($status); ?></li>
        <li><strong><?php esc_html_e( 'From:', 'citycourier-local-courier-booking-tracking-system' ); ?></strong> <?php echo esc_html($origin); ?></li>
<li><strong><?php esc_html_e( 'To:', 'citycourier-local-courier-booking-tracking-system' ); ?></strong> <?php echo esc_html($destination); ?></li>
<li><strong><?php esc_html_e( 'Estimated Duration:', 'citycourier-local-courier-booking-tracking-system' ); ?></strong> <?php echo esc_html($duration); ?></li>

        <li><strong><?php esc_html_e( 'Total Fee:', 'citycourier-local-courier-booking-tracking-system' ); ?></strong> <?php echo esc_html( $currency_symbol . number_format( $total_fee, 2, '.', ',' ) ); ?></li>
        <?php if ( $whatsapp_number ) : ?>
            <li>
                <strong><?php esc_html_e( 'Contact:', 'citycourier-local-courier-booking-tracking-system' ); ?></strong>
                <a href="<?php echo esc_url( $whatsapp_href ); ?>"><?php echo esc_html( $whatsapp_number ); ?></a>
            </li>
        <?php endif; ?>
    </ul>
</div>

<?php
get_footer();

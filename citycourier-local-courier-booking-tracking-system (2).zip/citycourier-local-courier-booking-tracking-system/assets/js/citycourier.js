document.addEventListener("DOMContentLoaded", function () {
  var settings = window.CityCourierData || {};

  function updateTotalPrice(distance_km) {
    var kmPrice = parseFloat(settings.km_price || 0);
    var minPrice = parseFloat(settings.minimum_price || 0);
    var total = Math.max(minPrice, Math.round(minPrice + distance_km * kmPrice));
    var symbol = settings.currency_symbol || settings.currency_code || "$";
    var el = document.querySelector(".dv-order-total-price__value span");
    if (el) el.textContent = symbol + " " + total;
    var hidden = document.getElementById("total_price");
    if (hidden) hidden.value = total;
  }

  function calcRouteDistance(origin, destination, callback) {
    if (!window.google || !window.google.maps) {
      updateTotalPrice(0);
      if (typeof callback === "function") callback(0);
      return;
    }
    const service = new google.maps.DistanceMatrixService();
    service.getDistanceMatrix(
      {
        origins: [origin],
        destinations: [destination],
        travelMode: "DRIVING",
        unitSystem: google.maps.UnitSystem.METRIC,
      },
      function (response, status) {
        if (
          status === "OK" &&
          response.rows.length > 0 &&
          response.rows[0].elements[0].status === "OK"
        ) {
          const distanceText = response.rows[0].elements[0].distance.text;
          const km = parseFloat(distanceText.replace(",", "."));
          updateTotalPrice(km);
          if (typeof callback === "function") callback(km);
        } else {
          updateTotalPrice(0);
          if (typeof callback === "function") callback(0);
        }
      }
    );
  }

  function tryUpdatePrice() {
    var fromInput = document.getElementById("address_from");
    var toInput = document.getElementById("address_to");
    var from = fromInput ? fromInput.value.trim() : "";
    var to = toInput ? toInput.value.trim() : "";
    if (from.length > 6 && to.length > 6) {
      calcRouteDistance(from, to, updateTotalPrice);
    } else {
      updateTotalPrice(0);
    }
  }

  function mapsReadyStart() {
    var fromInput = document.getElementById("address_from");
    var toInput = document.getElementById("address_to");
    if (
      fromInput &&
      toInput &&
      window.google &&
      window.google.maps &&
      window.google.maps.places
    ) {
      var fromAutocomplete = new google.maps.places.Autocomplete(fromInput, {
        types: ["geocode"],
        componentRestrictions: { country: settings.country }
      });
      var toAutocomplete = new google.maps.places.Autocomplete(toInput, {
        types: ["geocode"],
        componentRestrictions: { country: settings.country }
      });

      fromAutocomplete.addListener('place_changed', tryUpdatePrice);
      toAutocomplete.addListener('place_changed', tryUpdatePrice);

      fromInput.addEventListener('change', tryUpdatePrice);
      toInput.addEventListener('change', tryUpdatePrice);
    }
    updateTotalPrice(0);
  }

  function checkGoogleReadyAndInit() {
    if (
      window.google &&
      window.google.maps &&
      window.google.maps.places
    ) {
      mapsReadyStart();
    } else {
      setTimeout(checkGoogleReadyAndInit, 300); 
    }
  }
  checkGoogleReadyAndInit();

  window.fillSummary = function() {
    const summary = document.querySelector(".summary-output");
    if (!summary) return;

    var address_from_el = document.querySelector("[name='address_from']");
    var address_to_el = document.querySelector("[name='address_to']");
    var package_type_el = document.querySelector("[name='package_type']");
    var package_weight_el = document.querySelector("[name='package_weight']");
    var weight_unit_el = document.querySelector("[name='weight_unit']");
    var slot_el = document.querySelector("[name='delivery_slot']");
    var sender_el = document.querySelector("[name='sender_name']");
    var name_el = document.querySelector("[name='user_name']");
    var phone_el = document.querySelector("[name='user_phone']");
    var email_el = document.querySelector("[name='user_email']");
    var note_el = document.querySelector("[name='user_note']");

    var data = {
      address_from: address_from_el ? address_from_el.value : "",
      address_to: address_to_el ? address_to_el.value : "",
      package_type: package_type_el ? package_type_el.value : "",
      package_weight:
        (package_weight_el ? package_weight_el.value : "") + " " +
        (weight_unit_el ? weight_unit_el.value : ""),
      slot: slot_el ? slot_el.value : "",
      sender: sender_el ? sender_el.value : "",
      name: name_el ? name_el.value : "",
      phone: phone_el ? phone_el.value : "",
      email: email_el ? email_el.value : "",
      note: note_el ? note_el.value : "",
    };

    summary.innerHTML = 
      '<p><strong>Gönderici:</strong> ' + data.sender + ' – ' + data.address_from + '</p>' +
      '<p><strong>Teslimat:</strong> ' + data.name + ' – ' + data.address_to + '</p>' +
      '<p><strong>Paket Türü:</strong> ' + data.package_type + '</p>' +
      '<p><strong>Ağırlık:</strong> ' + data.package_weight + '</p>' +
      '<p><strong>Teslimat Saati:</strong> ' + data.slot + '</p>' +
      '<p><strong>Telefon:</strong> ' + data.phone + '</p>' +
      '<p><strong>Email:</strong> ' + data.email + '</p>' +
      '<p><strong>Ek Not:</strong> ' + data.note + '</p>';
  };

});

jQuery(function($){
  var form = $('#citycourier-form');
  var btn  = form.find('button[type=submit]');
  var responseBox = $('#cc-response');

  form.off('submit').on('submit', function(e){
    e.preventDefault();
    if ( btn.prop('disabled') ) return;
    btn.prop('disabled', true).text('Gönderiliyor…');
    responseBox.text('');

    $.ajax({
      url: form.attr('action') || '',
      method: 'POST',
      data: form.serialize(),
      dataType: 'json',
    })
    .done(function(res){
      if ( res.success ) {
        var redirectURL = (res.data && res.data.redirect_url) || res.redirect_url;
        if ( redirectURL ) {
          window.location.href = redirectURL;
        } else {
          responseBox.text('Yönlendirme adresi bulunamadı.');
        }
      } else {
        var err = (res.data) || res.message || 'Bir hata oluştu, lütfen tekrar deneyin.';
        responseBox.text(err);
      }
    })
    .fail(function(xhr){
      var msg = 'Sunucu hatası, lütfen tekrar deneyin.';
      if ( xhr.responseJSON ) {
        msg = xhr.responseJSON.data || xhr.responseJSON.message || msg;
      }
      responseBox.text(msg);
    })
    .always(function(){
      btn.prop('disabled', false).text('Siparişi Gönder');
    });
  });
});


document.addEventListener('DOMContentLoaded', function() {
  const quickTags = document.querySelectorAll('.quick-tags span');
  const input = document.querySelector('input[name="package_content"]');

  quickTags.forEach(function(tag) {
    tag.addEventListener('click', function() {
      input.value = tag.textContent;
      input.focus();
    });
  });
});


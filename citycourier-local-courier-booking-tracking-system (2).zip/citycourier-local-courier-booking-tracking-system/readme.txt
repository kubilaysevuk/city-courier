=== CityCourier – Local Courier Booking & Tracking System ===
Contributors: gksoftdev
Tags: courier, delivery, shipping calculator, order tracking, woocommerce
Requires at least: 5.6
Tested up to: 6.8
Requires PHP: 7.2
Stable tag: 1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Courier booking form with Google Maps integration, distance-based pricing, and order tracking. Built for WooCommerce.

== Description ==

⚠️ **WooCommerce is required.** This plugin relies on WooCommerce to process courier orders and manage order IDs. Please ensure WooCommerce is installed and activated before using CityCourier.

CityCourier is a lightweight WooCommerce courier plugin that enables local delivery businesses to accept courier requests with distance-based pricing and track deliveries through auto-generated pages.

Features include:
- Customizable courier request form
- Google Maps Distance Matrix API integration
- Km-based price calculation
- Address autocomplete with Google Places API
- Order summary with calculated price
- WooCommerce integration (Lite)
- Automatic shortcode page creation (no manual setup required)

== How It Works ==

Upon activation, CityCourier automatically creates:
- A **Courier Form** page (`[citycourier_form]`) for users to request delivery
- A **Courier Tracking** page (`[citycourier_tracking]`) for users to check order status

**Customers** can:
- Fill out pickup & delivery details
- Choose payment method
- Submit orders directly

**Admins** can:
- View orders in the WordPress dashboard
- Manage order status & customer details
- Customize API keys, pricing settings, currency, and country

== Installation ==

1. Make sure WooCommerce is installed and activated.
2. Upload and activate the plugin.
3. Two pages will be auto-created:
   - **Courier Form**: `/courier-form/`
   - **Courier Tracking**: `/courier-tracking/`
4. Optionally, use `[citycourier_form]` on any other page if needed.

== Screenshots ==

1. Courier order form – pickup & delivery with Google Maps integration.
2. Order tracking page – check order status using order ID.
3. Admin orders list – manage courier orders from the dashboard.
4. Plugin settings page – configure pricing, API keys, and currency.
== Privacy ==

This plugin uses the Google Maps JavaScript API and the Google Distance Matrix API to enable address autocomplete and to calculate the distance and estimated delivery time between pickup and delivery points. These Google services are used **solely for processing courier orders and facilitating order calculations**.

CityCourier **does not track users or collect any analytics data**.  
No user information is stored or used for marketing, analytics, or tracking purposes without explicit consent.  
All data is processed only as part of the courier order workflow.

See also the [Google Maps Terms of Service](https://maps.google.com/help/terms_maps/) and [Google Privacy Policy](https://policies.google.com/privacy).

If you enable WooCommerce integration, user and order details are handled according to your WooCommerce and WordPress site policies.

== Changelog ==

= 1.1 =
* Initial public release – courier form, order tracking, and admin panel

== Upgrade Notice ==

Development on the Pro version is ongoing. New features such as Stripe payments, advanced delivery options, and reporting are coming soon.  
https://gksoft.dev for updates.
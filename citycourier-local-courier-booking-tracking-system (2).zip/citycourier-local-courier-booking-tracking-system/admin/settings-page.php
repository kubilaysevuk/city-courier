<?php
/**
 * admin/settings-page.php
 * Admin settings page
 */
if (!defined('ABSPATH')) exit;

add_action('admin_init', 'citycourier_register_settings');
function citycourier_register_settings() {
    register_setting('citycourier_settings_group', 'citycourier_email', [
    'sanitize_callback' => 'sanitize_text_field'
]);
    register_setting('citycourier_settings_group', 'citycourier_google_api_key', [
    'sanitize_callback' => 'sanitize_text_field'
]);
    register_setting('citycourier_settings_group', 'citycourier_country', [
    'sanitize_callback' => 'sanitize_text_field'
]);
    register_setting('citycourier_settings_group', 'citycourier_currency', [
    'sanitize_callback' => 'sanitize_text_field'
]);
    register_setting('citycourier_settings_group', 'citycourier_km_price', [
    'sanitize_callback' => 'sanitize_text_field'
]);
    register_setting('citycourier_settings_group', 'citycourier_minimum_price', [
    'sanitize_callback' => 'sanitize_text_field'
]);
    register_setting('citycourier_settings_group', 'citycourier_max_distance', [
    'sanitize_callback' => 'sanitize_text_field'
]);
    register_setting('citycourier_settings_group', 'citycourier_whatsapp_number', [
    'sanitize_callback' => 'sanitize_text_field'
]);
    register_setting('citycourier_settings_group', 'citycourier_notify_admin', [
    'sanitize_callback' => 'sanitize_text_field'
]);
    register_setting('citycourier_settings_group', 'citycourier_notify_whatsapp', [
    'sanitize_callback' => 'sanitize_text_field'
]);
}

function citycourier_settings_page_html() {
echo '<div class="notice notice-info is-dismissible">';
echo '<p><strong>🚀 Setup Completed!</strong></p>';
echo '<p>You can now use the <code>[citycourier_form]</code> shortcode on any page to display the courier form.</p>';

$page_id = get_option('citycourier_form_page_id');
if ($page_id && get_post_status($page_id) === 'publish') {
    $url = get_permalink($page_id);
    echo '<p>✅ Automatically created page: <a href="' . esc_url($url) . '" target="_blank">' . esc_html($url) . '</a></p>';
}
echo '</div>';
    ?>
    
    <div class="wrap">
        <h1>CityCourier Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields('citycourier_settings_group'); ?>
            <?php do_settings_sections('citycourier_settings_group'); ?>

            <table class="form-table">
                <tr>
                <th>Google Maps API Key</th>
                <td>
                    <input type="text" name="citycourier_google_api_key" value="<?php echo esc_attr(get_option('citycourier_google_api_key')); ?>" style="width: 400px;" />
                <p class="description">
                Enter your <strong>Google Maps API Key</strong> to enable address autocomplete and distance calculation.<br>
                Required APIs that must be enabled from your Google Cloud Console:
                <ul style="margin-top: 8px; padding-left: 20px; list-style-type: disc;">
                <li><strong>Maps JavaScript API</strong></li>
                <li><strong>Places API</strong></li>
                <li><strong>Distance Matrix API</strong></li>
                </ul>
                Get your key at <a href="https://console.cloud.google.com/" target="_blank">Google Cloud Console</a>. Don’t forget to restrict the key for security.
                </p>
                </td>
                </tr>
                <tr>
    <th>Country</th>
    <td>
        <select name="citycourier_country" style="width: 250px;">
            <?php
            $selected_country = get_option('citycourier_country', 'TR');
            $countries = [
    'TR' => 'Turkey',
    'US' => 'United States',
    'GB' => 'United Kingdom',
    'DE' => 'Germany',
    'FR' => 'France',
    'IT' => 'Italy',
    'ES' => 'Spain',
    'CA' => 'Canada',
    'AU' => 'Australia',
    'NL' => 'Netherlands',
    'BE' => 'Belgium',
    'CH' => 'Switzerland',
    'AT' => 'Austria',
    'AE' => 'United Arab Emirates',
    'RU' => 'Russia',
    'IN' => 'India',
    'CN' => 'China',
    'JP' => 'Japan',
    'BR' => 'Brazil',
    'ZA' => 'South Africa',
    'PL' => 'Poland',
    'SE' => 'Sweden',
    'NO' => 'Norway',
    'FI' => 'Finland',
    'DK' => 'Denmark',
    'GR' => 'Greece',
    'RO' => 'Romania',
    'PT' => 'Portugal',
    'MX' => 'Mexico',
    'AR' => 'Argentina',
    'ID' => 'Indonesia',
    'MY' => 'Malaysia',
    'KR' => 'South Korea',
    'UA' => 'Ukraine',
    'IL' => 'Israel',
    'IR' => 'Iran',
    'SA' => 'Saudi Arabia',
];

            foreach ($countries as $code => $name) {
                echo '<option value="' . esc_attr($code) . '" ' . selected($selected_country, $code, false) . '>' . esc_html($name) . '</option>';
            }
            ?>
        </select>
        <p class="description">Google Maps autocomplete is limited to the selected country.</p>
    </td>
</tr>
                <tr>
    <th>Currency</th>
    <td>
        <select name="citycourier_currency" style="width: 250px;">
            <?php
            $selected_currency = get_option('citycourier_currency', 'USD');
            $currencies = [
                'USD' => '$ US Dollar',
                'EUR' => '€ Euro',
                'GBP' => '£ British Pound',
                'TRY' => '₺ Turkish Lira',
                'CAD' => 'C$ Canadian Dollar',
                'AUD' => 'A$ Australian Dollar',
                'CHF' => 'CHF Swiss Franc',
                'JPY' => '¥ Japanese Yen',
                'CNY' => '¥ Chinese Yuan',
                'AED' => 'د.إ UAE Dirham',
                'INR' => '₹ Indian Rupee',
                'BRL' => 'R$ Brazilian Real',
                'ZAR' => 'R South African Rand',
                'KRW' => '₩ South Korean Won',
                'MXN' => '$ Mexican Peso',
            ];
            foreach ($currencies as $code => $label) {
                echo '<option value="' . esc_attr($code) . '" ' . selected($selected_currency, $code, false) . '>' . esc_html($label) . '</option>';
            }
            ?>
        </select>
        <p class="description">All prices and symbols will be displayed in the selected currency.</p>
    </td>
</tr>
                <tr>
                    <th>Km Based Pricing</th>
                    <td><input type="number" name="citycourier_km_price" value="<?php echo esc_attr(get_option('citycourier_km_price')); ?>" step="0.01" /></td>
                </tr>
                <tr>
                    <th>Minimum Service Pricing</th>
                    <td><input type="number" name="citycourier_minimum_price" value="<?php echo esc_attr(get_option('citycourier_minimum_price')); ?>" step="0.01" /></td>
                </tr>
                <tr>
                    <th>Maximum Distance (km)</th>
                    <td><input type="number" name="citycourier_max_distance" value="<?php echo esc_attr(get_option('citycourier_max_distance')); ?>"/></td>
                </tr>
                <tr>
                    <th>Contact Number</th>
                    <td><input type="text" name="citycourier_whatsapp_number" value="<?php echo esc_attr(get_option('citycourier_whatsapp_number')); ?>" placeholder="90XXXXXXXXXX" /></td>
                </tr>
            </table>
            <?php submit_button('Ayarları Kaydet'); ?>
        </form>
    </div>
    <?php
}

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script('citycourier-form', plugins_url('/assets/js/citycourier.js', __FILE__), ['jquery'], '1.0', true);

    wp_localize_script('citycourier-form', 'CityCourierSettings', [
        'country' => get_option('citycourier_country', 'TR')
    ]);
});




function citycourier_orders_page_html() {
    // Order status update işlemi
    if (
    isset($_SERVER['REQUEST_METHOD']) &&
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['update_order_status_id'], $_POST['update_status_nonce'], $_POST['new_status'])
) {
    $nonce = sanitize_text_field( wp_unslash($_POST['update_status_nonce']) );
    if ( ! wp_verify_nonce($nonce, 'update_status_action') ) {
        wp_safe_redirect( admin_url('admin.php?page=citycourier-orders&error=nonce') );
        exit;
    }

    $order_id   = absint( wp_unslash($_POST['update_order_status_id']) );
    $new_status = sanitize_text_field( wp_unslash($_POST['new_status']) );
    $order      = wc_get_order($order_id);

    $statuses = array_keys(wc_get_order_statuses());
    if ( $order && in_array($new_status, $statuses, true) ) {
        $order->update_status( str_replace('wc-', '', $new_status) );
        $order->save();
        wp_safe_redirect( admin_url('admin.php?page=citycourier-orders&status_updated=1') );
        exit;
    }
    wp_safe_redirect( admin_url('admin.php?page=citycourier-orders&error=update') );
    exit;
}


    
$currency_code = get_option('citycourier_currency', 'USD');
$symbols = [
    'USD' => '$',
    'EUR' => '€',
    'GBP' => '£',
    'TRY' => '₺',
    'CAD' => 'C$',
    'AUD' => 'A$',
    'CHF' => 'CHF',
    'JPY' => '¥',
    'CNY' => '¥',
    'AED' => 'د.إ',
    'INR' => '₹',
    'BRL' => 'R$',
    'ZAR' => 'R',
    'KRW' => '₩',
    'MXN' => '$',
];
$currency_symbol = $symbols[$currency_code] ?? '$';

    echo '<div class="wrap"><h1>Courier Orders</h1>';

    if (isset($_GET['status_updated'])) {
        echo '<div class="updated notice"><p>Order status successfully updated.</p></div>';
    } elseif (isset($_GET['error'])) {
        $msg = ($_GET['error'] === 'nonce') ? 'Security error. Please refresh and try again.' : 'An error occurred. Please try again.';
        echo '<div class="error notice"><p>' . esc_html($msg) . '</p></div>';
    }

    $orders = wc_get_orders([
        'limit'    => 50,
        'orderby'  => 'date',
        'order'    => 'DESC',
        'meta_key' => '_cc_address_from',
    ]);

    if (empty($orders)) {
        echo '<p>No orders yet.</p></div>';
        return;
    }

    echo '<table class="widefat fixed striped">';
    echo '<thead><tr>
            <th>ID</th><th>From → To</th><th>Content</th>
            <th>Weight</th><th>Total</th><th>Status</th><th>Update</th>
        </tr></thead><tbody>';

foreach ($orders as $order) {
    $id       = $order->get_id();
    $from     = esc_html($order->get_meta('_cc_address_from'));
    $to       = esc_html($order->get_meta('_cc_address_to'));
    $package  = esc_html($order->get_meta('_cc_package_content'));
    $weight   = esc_html($order->get_meta('_cc_weight'));
    $total    = esc_html($currency_symbol . $order->get_meta('_cc_total_price'));
    $status   = $order->get_status();

    echo '<tr class="order-row" data-id="' . esc_attr($id) . '">';
    echo '<td><button class="toggle-details button" type="button" data-target="details-' . esc_attr($id) . '">🔽</button> <span>#' . esc_html($id) . '</span></td>';
    echo '<td>' . esc_html($from) . ' &rarr; ' . esc_html($to) . '</td>'
   . '<td>' . esc_html($package) . '</td>'
   . '<td>' . esc_html($weight) . '</td>'
   . '<td>' . esc_html($total) . '</td>';

    echo '<td>' . esc_html(wc_get_order_status_name($status)) . '</td>';

    // Status form
    echo '<td style="display:flex; flex-wrap:wrap; gap:4px; align-items:center;"><form method="post" style="display:flex; gap:5px;">';
    wp_nonce_field('update_status_action', 'update_status_nonce');
    echo '<input type="hidden" name="update_order_status_id" value="' . esc_attr($id) . '">';
    echo '<select name="new_status" style="max-width:120px; font-size:12px;">';
    foreach (wc_get_order_statuses() as $status_key => $status_name) {
        $selected = ($status_key === "wc-$status") ? 'selected' : '';
        echo '<option value="' . esc_attr($status_key) . '" ' . esc_attr($selected) . '>' . esc_html($status_name) . '</option>';
    }
    echo '</select>';
    echo '<button type="submit" class="button" style="padding: 3px 3px; font-size: 12px;">Update</button></form></td>';
    echo '</tr>';

    echo '<tr id="details-' . esc_attr($id) . '" class="order-details" style="display:none;"><td colspan="7">';
    echo '<div style="background: #f9f9f9; border: 1px solid #e2e8ec; border-radius: 8px; padding: 20px; margin-top: 10px;">';
    echo '<h3 style="margin-top:0; font-size: 16px; color:#333;">Order Details</h3>';
    echo '<table style="width:100%; border-collapse:collapse;">';

    $fields = [
        'Pickup Address'      => $from,
        'Delivery Address'    => $to,
        'Pickup Phone'        => esc_html($order->get_meta('_cc_pickup_phone')),
        'Delivery Phone'      => esc_html($order->get_meta('_cc_delivery_phone')),
        'Sender Name'         => esc_html($order->get_meta('_cc_sender_name')),
        'Customer Name'       => esc_html($order->get_meta('_cc_user_name')),
        'Customer Email'      => esc_html($order->get_meta('_cc_user_email')),
        'Pickup Details'      => esc_html($order->get_meta('_cc_pickup_details')),
        'Delivery Details'    => esc_html($order->get_meta('_cc_delivery_details')),
        'Package Content'     => esc_html($order->get_meta('_cc_package_content')),
        'Weight'              => esc_html($order->get_meta('_cc_weight')),
        'Payment Method'      => esc_html($order->get_meta('_cc_payment_method')),
        'Total Price'         => esc_html('₺' . $order->get_meta('_cc_total_price')),
        'Estimated Duration'  => esc_html($order->get_meta('_cc_duration')),
    ];

    foreach ($fields as $label => $value) {
        echo '<tr style="border-bottom: 1px solid #eee;"><td style="padding: 8px 6px; font-weight: 600; color:#444; width: 180px;">' . esc_html($label) . ':</td>';
        echo '<td style="padding: 8px 6px; color:#222;">' . esc_html($value) . '</td></tr>';
    }

    echo '</table></div></td></tr>';
}


    echo '</tbody></table></div>';

    // jQuery toggle
    echo '<script>
    jQuery(document).ready(function($){
        $(".toggle-details").on("click", function(){
            const target = $(this).data("target");
            $("#" + target).toggle();
        });
    });
    </script>';
}







function citycourier_contact_page_html() {
    echo '<div class="wrap" style="max-width:700px;">';
    echo '<h1>📨 CityCourier Contact</h1>';
    echo '<p>If you need help or have suggestions, please visit our contact page below:</p>';
    echo '<p><a href="https://gksoft.com.tr/iletisim" class="button button-primary" target="_blank">Open Contact Page</a></p>';
    echo '</div>';
}
